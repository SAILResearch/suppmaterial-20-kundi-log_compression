// unsr2.cpp file decompressor.
// To decompress a file compressed with sr2: unsr2 input output

// (C) 2007, Matt Mahoney, matmahoney@yahoo.com
// Free software under GPL, see sr2.cpp for license and docs.

#include "sr2.h"

// A Decoder does arithmetic decoding in n contexts.  Methods:
// Decoder(f, n) creates decoder for decompression from archive f,
//     which must be open past any header for reading in binary mode.
// code(cxt) returns the next decompressed bit from file f
//   with context cxt in 0..n-1.

class Decoder {
private:
  const int N;     // number of contexts
  FILE* archive;   // Compressed data file
  U32 x1, x2;      // Range, initially [0, 1), scaled by 2^32
  U32 x;           // Decompress mode: last 4 input bytes of archive
  StateMap sm;     // cxt -> p
public:
  Decoder(FILE* f, int n);
  int code(int cxt);  // decompress a bit
};

// Return decompressed bit (0..1) in context cxt (0..n-1)
inline int Decoder::code(int cxt) {
  assert(cxt>=0 && cxt<N);
  int p=sm.p(cxt);
  assert(p>=0 && p<4096);
  U32 xmid=x1 + (x2-x1>>12)*p;
  assert(xmid>=x1 && xmid<x2);
  int y=x<=xmid;
  y ? (x2=xmid) : (x1=xmid+1);
  sm.update(cxt, y);
  while (((x1^x2)&0xff000000)==0) {  // pass equal leading bytes of range
    x1<<=8;
    x2=(x2<<8)+255;
    x=(x<<8)+(getc(archive)&255);  // EOF is OK
  }
  return y;
}

Decoder::Decoder(FILE* f, int n):
    N(n), archive(f), x1(0), x2(0xffffffff), x(0), sm(n) {
  for (int i=0; i<4; ++i)
    x=(x<<8)+(getc(archive)&255);
}

// Decode one byte
int decode(Decoder& e, int cxt) {
  int hi=1, lo=1;  // high and low nibbles
  hi+=hi+e.code(cxt+hi);
  hi+=hi+e.code(cxt+hi);
  hi+=hi+e.code(cxt+hi);
  hi+=hi+e.code(cxt+hi);
  cxt+=15*(hi-15);
  lo+=lo+e.code(cxt+lo);
  lo+=lo+e.code(cxt+lo);
  lo+=lo+e.code(cxt+lo);
  lo+=lo+e.code(cxt+lo);
  return hi-16<<4|(lo-16);
}

// Decompress from in to out.  in should be positioned past the header.
void decompress(FILE *in, FILE *out) {
  Decoder e(in, (1024+64)*258);
  int c1=0;  // previous byte
  U32 h=0;   // hash of last 4 bytes
  U32 *t4;   // context -> last 3 bytes in bits 0..23, count in 24..29
  alloc(t4, 0x100000);
  while (1) {
    const U32 r=t4[h];  // last byte count, last 3 bytes in this context
    int cxt;  // context
    if (r>=0x4000000) cxt=1024+(r>>24);
    else cxt=c1|r>>16&0x3f00;
    cxt*=258;

    // Decompress: 0=p[1], 110=p[2], 111=p[3], 10xxxxxxxx=literal.
    // EOF is marked by p[1] coded as a literal.
    if (e.code(cxt)) {
      if (e.code(cxt+1)) {
        if (e.code(cxt+2)) {  // match third?
          c1=r>>16&0xff;
          t4[h]=r<<8&0xffff00|c1|0x1000000;
        }
        else {  // match second?
          c1=r>>8&0xff;
          t4[h]=r&0xff0000|r<<8&0xff00|c1|0x1000000;
        }
      }
      else {  // literal?
        c1=decode(e, cxt+2);
        if (c1==int(r&0xff)) break;  // EOF?
        t4[h]=r<<8&0xffff00|c1;
      }
    }
    else {  // match first?
      c1=r&0xff;
      if (r<0x3f000000) t4[h]+=0x1000000;  // increment count
    }
    putc(c1, out);
    h=h*(5<<5)+c1+1&0xfffff;
  }
}

// User interface.  Args are input and output file.
int main(int argc, char **argv) {

  // Check arguments
  if (argc!=3) {
    printf(
      "unsr2 file decompressor (C) 2007, Matt Mahoney\n"
      "Licensed under GPL, http://www.gnu.org/copyleft/gpl.html\n"
      "\n"
      "To decompress: unsr2 input output\n");
    return 1;
  }

  // Get start time
  clock_t start=clock();

  // Decompress
  FILE *in=fopen(argv[1], "rb");
  if (!in) perror(argv[1]), exit(1);
  FILE *out=0;
  if (getc(in)!='s' || getc(in)!='R' || getc(in)!=2)
    quit("Not a SR2 file");
  out=fopen(argv[2], "wb");
  if (!out) perror(argv[2]), exit(1);
  decompress(in, out);

  // Report result
  assert(in);
  assert(out);
  printf("%ld -> %ld in %1.2f sec.\n", 
    ftell(in), ftell(out), double(clock()-start)/CLOCKS_PER_SEC);
  return 0;
}
