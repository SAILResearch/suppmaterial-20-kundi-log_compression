// sr2.h - common code for sr2.cpp and unsr2.cpp file compressor.

// (C) 2007, Matt Mahoney.
// Free software under GPL, see sr2.cpp for license and docs.

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define NDEBUG  // remove for debugging
#include <assert.h>

// 8, 16, 32 bit unsigned types (adjust as appropriate)
typedef unsigned char  U8;
typedef unsigned short U16;
typedef unsigned int   U32;

// Error handler: print message if any, and exit
void quit(const char* message=0) {
  if (message) printf("%s\n", message);
  exit(1);
}

// Create an array p of n elements of type T
template <class T> void alloc(T*&p, int n) {
  p=(T*)calloc(n, sizeof(T));
  if (!p) quit("out of memory");
}

// A StateMap maps a secondary context to a probability.  Methods:
//
// Statemap sm(n) creates a StateMap with n contexts using 4*n bytes memory.
// sm.p(cxt) predicts next bit (0..4K-1) in context cxt (0..n-1).
// sm.update(cxt, y) updates model for actual bit y (0..1) in cxt (0..n-1).

class StateMap {
protected:
  const int N;  // Number of contexts
  U32 *t;       // cxt -> prediction in high 25 bits, count in low 7 bits
  static int dt[128];  // i -> 1K/(i+2)
public:
  StateMap(int n);

  // predict next bit in context cxt
  int p(int cxt) {
    assert(cxt>=0 && cxt<N);
    return t[cxt]>>20;
  }

  // update model in context cxt for actual bit y
  void update(int cxt, int y) {
    assert(cxt>=0 && cxt<N);
    assert(y==0 || y==1);
    int n=t[cxt]&127, p=t[cxt]>>9;  // count, prediction
    if (n<127) ++t[cxt];
    t[cxt]+=((y<<23)-p)*dt[n]&0xffffff80;
  }
};

int StateMap::dt[128]={0};

StateMap::StateMap(int n): N(n) {
  alloc(t, N);
  for (int i=0; i<N; ++i)
    t[i]=1<<31;
  if (dt[0]==0)
    for (int i=0; i<128; ++i)
      dt[i]=512/(i+2);
}
